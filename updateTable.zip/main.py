import globalvars as g
import alphavantage  as av
import dynamodb as ddb

def lambda_handler(event, context):
    
    av.main()
    ddb.main()
    
    return "Query executed successfully"


        