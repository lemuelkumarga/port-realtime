# Global variables to store relevant information
debug = False
cur_dt = None
tickers = ['VTI','VXUS']
cache = {}
