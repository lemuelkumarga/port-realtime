import requests
import csv

import globalvars as g

# API parameters
api = '<Get your own API at alphavantage.co>'
interval = '1min'
outputsize = 'compact'
datatype = 'csv'
webpage = 'https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&' \
            + 'interval=' + interval + '&' \
            + 'outputsize=' + outputsize + '&' \
            + 'datatype=' + datatype + '&' \
            + 'apikey=' + api  + '&'

# Returns the latest realtime prices for the ticker
def get_realtime_prices(ticker):
    
    response = requests.get(webpage + 'symbol=' + ticker);
    
    # Throw error if fail to load prices
    if (response.status_code != 200):
        raise Error('Failed to load prices for ticker ' + ticker + '.')
    
    # Read the ping results
    rd = csv.reader(response.content.decode('ascii').splitlines(), delimiter=',')
    # skip first line since it's the header
    next(rd)
    
    # Parse the information into the cache
    for row in rd:
        
        # Get values
        d, t = row[0].split(' ')
        val = row[1]

        # Set current date in the first iteration
        if (g.cur_dt is None):
            g.cur_dt = d
        # We only want to collect prices for current date. 
        # Ignore all previous date prices
        elif (g.cur_dt > d):
            break
        
        # Set time as the keys in cache
        if (t not in g.cache.keys()):
            g.cache[t] = {}
        
        g.cache[t][ticker] = float(val)
        

# Main function to ping stock prices 
def main():
    
    for i in g.tickers:
        get_realtime_prices(i)